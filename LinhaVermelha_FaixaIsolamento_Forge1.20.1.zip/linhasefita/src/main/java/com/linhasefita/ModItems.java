package com.linhasefita;

import com.linhasefita.entity.ConnectionEntity;
import com.linhasefita.item.ConnectorItem;
import com.linhasefita.item.LupaItem;
import com.linhasefita.item.ScissorsItem;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModItems {
    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, LinhasEFita.MODID);
    public static final DeferredRegister<CreativeModeTab> TABS =
            DeferredRegister.create(Registries.CREATIVE_MODE_TAB, LinhasEFita.MODID);

    public static final RegistryObject<Item> LINHA_VERMELHA = ITEMS.register("linha_vermelha",
            () -> new ConnectorItem(ConnectionEntity.KIND_STRING, new Item.Properties().stacksTo(1)));
    public static final RegistryObject<Item> FAIXA_ISOLAMENTO = ITEMS.register("faixa_isolamento",
            () -> new ConnectorItem(ConnectionEntity.KIND_TAPE, new Item.Properties().stacksTo(1)));
    public static final RegistryObject<Item> TESOURA = ITEMS.register("tesoura",
            () -> new ScissorsItem(new Item.Properties().stacksTo(1)));

    public static final RegistryObject<Item> LUPA = ITEMS.register("lupa",
            () -> new LupaItem(new Item.Properties()));

    public static final RegistryObject<CreativeModeTab> TAB = TABS.register("principal",
            () -> CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup.linhasefita"))
                    .icon(() -> new ItemStack(LINHA_VERMELHA.get()))
                    .displayItems((params, out) -> {
                        out.accept(LINHA_VERMELHA.get());
                        out.accept(FAIXA_ISOLAMENTO.get());
                        out.accept(TESOURA.get());
                        out.accept(LUPA.get());
                    })
                    .build());
}
