package com.linhasefita.entity;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.network.NetworkHooks;

/** Segmento entre dois pontos: posição da entidade = ponto A; B = A + offset. */
public class ConnectionEntity extends Entity {
    public static final int KIND_STRING = 0;
    public static final int KIND_TAPE = 1;

    private static final EntityDataAccessor<Float> OX = SynchedEntityData.defineId(ConnectionEntity.class, EntityDataSerializers.FLOAT);
    private static final EntityDataAccessor<Float> OY = SynchedEntityData.defineId(ConnectionEntity.class, EntityDataSerializers.FLOAT);
    private static final EntityDataAccessor<Float> OZ = SynchedEntityData.defineId(ConnectionEntity.class, EntityDataSerializers.FLOAT);
    private static final EntityDataAccessor<Integer> KIND = SynchedEntityData.defineId(ConnectionEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> FACE_A = SynchedEntityData.defineId(ConnectionEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> FACE_B = SynchedEntityData.defineId(ConnectionEntity.class, EntityDataSerializers.INT);

    public ConnectionEntity(EntityType<?> type, Level level) {
        super(type, level);
        this.noPhysics = true;
        this.setInvulnerable(true);
    }

    @Override
    protected void defineSynchedData() {
        entityData.define(OX, 0f);
        entityData.define(OY, 0f);
        entityData.define(OZ, 0f);
        entityData.define(KIND, KIND_STRING);
        entityData.define(FACE_A, Direction.UP.get3DDataValue());
        entityData.define(FACE_B, Direction.UP.get3DDataValue());
    }

    public void configure(int kind, Vec3 offset, Direction faceA, Direction faceB) {
        entityData.set(KIND, kind);
        entityData.set(OX, (float) offset.x);
        entityData.set(OY, (float) offset.y);
        entityData.set(OZ, (float) offset.z);
        entityData.set(FACE_A, faceA.get3DDataValue());
        entityData.set(FACE_B, faceB.get3DDataValue());
    }

    public int getKind() { return entityData.get(KIND); }
    public Vec3 getOffset() { return new Vec3(entityData.get(OX), entityData.get(OY), entityData.get(OZ)); }
    public Direction getFaceA() { return Direction.from3DDataValue(entityData.get(FACE_A)); }
    public Direction getFaceB() { return Direction.from3DDataValue(entityData.get(FACE_B)); }

    @Override
    public void tick() {
        super.tick();
        if (level().isClientSide || tickCount % 20 != 0) return;
        Vec3 a = position();
        Vec3 b = a.add(getOffset());
        if (!anchored(a, getFaceA()) || !anchored(b, getFaceB())) {
            discard();
        }
    }

    private boolean anchored(Vec3 p, Direction f) {
        BlockPos bp = BlockPos.containing(p.x - f.getStepX() * 0.05, p.y - f.getStepY() * 0.05, p.z - f.getStepZ() * 0.05);
        if (!level().hasChunkAt(bp)) return true;
        return !level().getBlockState(bp).isAir();
    }

    @Override
    protected void readAdditionalSaveData(CompoundTag tag) {
        configure(tag.getInt("kind"),
                new Vec3(tag.getDouble("ox"), tag.getDouble("oy"), tag.getDouble("oz")),
                Direction.from3DDataValue(tag.getInt("fa")),
                Direction.from3DDataValue(tag.getInt("fb")));
    }

    @Override
    protected void addAdditionalSaveData(CompoundTag tag) {
        Vec3 o = getOffset();
        tag.putInt("kind", getKind());
        tag.putDouble("ox", o.x);
        tag.putDouble("oy", o.y);
        tag.putDouble("oz", o.z);
        tag.putInt("fa", getFaceA().get3DDataValue());
        tag.putInt("fb", getFaceB().get3DDataValue());
    }

    @Override
    public boolean isPickable() { return false; }

    @Override
    public Packet<ClientGamePacketListener> getAddEntityPacket() {
        return NetworkHooks.getEntitySpawningPacket(this);
    }
}
