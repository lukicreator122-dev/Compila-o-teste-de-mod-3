package com.linhasefita.item;

import com.linhasefita.ModEntities;
import com.linhasefita.entity.ConnectionEntity;
import net.minecraft.core.Direction;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

/** Linha Vermelha (kind=0) e Faixa de Isolamento (kind=1): clique em pontos para ligá-los em sequência. */
public class ConnectorItem extends Item {
    public static final double MAX_DISTANCE = 48.0;
    private final int kind;

    public ConnectorItem(int kind, Properties props) {
        super(props);
        this.kind = kind;
    }

    private static boolean hasStart(ItemStack stack) {
        return stack.hasTag() && stack.getTag().contains("sx");
    }

    @Override
    public boolean isFoil(ItemStack stack) {
        return hasStart(stack);
    }

    @Override
    public boolean shouldCauseReequipAnimation(ItemStack oldStack, ItemStack newStack, boolean slotChanged) {
        return slotChanged || oldStack.getItem() != newStack.getItem();
    }

    private static void clear(ItemStack stack, Player player) {
        stack.setTag(null);
        player.displayClientMessage(Component.translatable("msg.linhasefita.reiniciado"), true);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (player.isShiftKeyDown() && hasStart(stack)) {
            if (!level.isClientSide) clear(stack, player);
            return InteractionResultHolder.sidedSuccess(stack, level.isClientSide);
        }
        return InteractionResultHolder.pass(stack);
    }

    @Override
    public InteractionResult useOn(UseOnContext ctx) {
        Level level = ctx.getLevel();
        Player player = ctx.getPlayer();
        ItemStack stack = ctx.getItemInHand();
        if (player == null) return InteractionResult.PASS;
        if (level.isClientSide) return InteractionResult.SUCCESS;

        if (player.isShiftKeyDown()) {
            if (hasStart(stack)) clear(stack, player);
            return InteractionResult.CONSUME;
        }

        Direction face = ctx.getClickedFace();
        Vec3 p = ctx.getClickLocation().add(face.getStepX() * 0.02, face.getStepY() * 0.02, face.getStepZ() * 0.02);
        CompoundTag tag = stack.getOrCreateTag();

        if (!tag.contains("sx")) {
            savePoint(tag, p, face);
            if (kind == ConnectionEntity.KIND_STRING) {
                spawn(level, p, face, p, face); // pino sozinho
            }
            player.displayClientMessage(Component.translatable("msg.linhasefita.ponto1"), true);
            level.playSound(null, p.x, p.y, p.z, SoundEvents.LEASH_KNOT_PLACE, SoundSource.PLAYERS, 1f, 1.2f);
            return InteractionResult.CONSUME;
        }

        Vec3 s = new Vec3(tag.getDouble("sx"), tag.getDouble("sy"), tag.getDouble("sz"));
        Direction sf = Direction.from3DDataValue(tag.getInt("sf"));
        double dist = s.distanceTo(p);
        if (dist > MAX_DISTANCE) {
            player.displayClientMessage(Component.translatable("msg.linhasefita.longe"), true);
            return InteractionResult.CONSUME;
        }
        if (dist < 0.1) return InteractionResult.CONSUME;

        spawn(level, s, sf, p, face);
        savePoint(tag, p, face); // continua a sequência a partir do novo ponto
        level.playSound(null, p.x, p.y, p.z, SoundEvents.LEASH_KNOT_PLACE, SoundSource.PLAYERS, 1f, 1f);
        return InteractionResult.CONSUME;
    }

    private static void savePoint(CompoundTag tag, Vec3 p, Direction face) {
        tag.putDouble("sx", p.x);
        tag.putDouble("sy", p.y);
        tag.putDouble("sz", p.z);
        tag.putInt("sf", face.get3DDataValue());
    }

    private void spawn(Level level, Vec3 a, Direction fa, Vec3 b, Direction fb) {
        ConnectionEntity e = new ConnectionEntity(ModEntities.CONEXAO.get(), level);
        e.setPos(a.x, a.y, a.z);
        e.configure(kind, b.subtract(a), fa, fb);
        level.addFreshEntity(e);
    }
}
