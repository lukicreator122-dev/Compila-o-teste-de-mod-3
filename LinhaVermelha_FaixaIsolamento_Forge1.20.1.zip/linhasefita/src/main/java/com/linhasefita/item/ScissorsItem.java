package com.linhasefita.item;

import com.linhasefita.entity.ConnectionEntity;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

/** Remove o fio/fita (ou pino) que estiver mais perto da mira. */
public class ScissorsItem extends Item {
    public ScissorsItem(Properties props) { super(props); }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (level.isClientSide) return InteractionResultHolder.success(stack);

        Vec3 eye = player.getEyePosition();
        Vec3 end = eye.add(player.getLookAngle().scale(10));
        ConnectionEntity best = null;
        double bestD = 0.4;
        for (ConnectionEntity e : level.getEntitiesOfClass(ConnectionEntity.class, player.getBoundingBox().inflate(60))) {
            Vec3 a = e.position();
            Vec3 b = a.add(e.getOffset());
            double d = segSegDist(eye, end, a, b);
            if (d < bestD) { bestD = d; best = e; }
        }
        if (best != null) {
            level.playSound(null, best.getX(), best.getY(), best.getZ(), SoundEvents.SHEEP_SHEAR, SoundSource.PLAYERS, 1f, 1f);
            best.discard();
        }
        return InteractionResultHolder.consume(stack);
    }

    private static double segSegDist(Vec3 p1, Vec3 q1, Vec3 p2, Vec3 q2) {
        Vec3 d1 = q1.subtract(p1), d2 = q2.subtract(p2), r = p1.subtract(p2);
        double a = d1.dot(d1), e = d2.dot(d2), f = d2.dot(r), s, t;
        final double EPS = 1.0E-9;
        if (a <= EPS && e <= EPS) return r.length();
        if (a <= EPS) {
            s = 0; t = Mth.clamp(f / e, 0.0, 1.0);
        } else {
            double c = d1.dot(r);
            if (e <= EPS) {
                t = 0; s = Mth.clamp(-c / a, 0.0, 1.0);
            } else {
                double b = d1.dot(d2);
                double denom = a * e - b * b;
                s = denom > EPS ? Mth.clamp((b * f - c * e) / denom, 0.0, 1.0) : 0.0;
                t = (b * s + f) / e;
                if (t < 0) { t = 0; s = Mth.clamp(-c / a, 0.0, 1.0); }
                else if (t > 1) { t = 1; s = Mth.clamp((b - c) / a, 0.0, 1.0); }
            }
        }
        Vec3 c1 = p1.add(d1.scale(s));
        Vec3 c2 = p2.add(d2.scale(t));
        return c1.distanceTo(c2);
    }
}
