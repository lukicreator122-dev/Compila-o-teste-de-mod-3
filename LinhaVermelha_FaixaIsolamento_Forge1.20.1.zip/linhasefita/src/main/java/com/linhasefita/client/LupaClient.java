package com.linhasefita.client;

import com.linhasefita.LinhasEFita;
import com.linhasefita.item.LupaItem;
import net.minecraft.client.Minecraft;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.ModelEvent;
import net.minecraftforge.client.event.RenderHandEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

public class LupaClient {
    private LupaClient() {}

    @Mod.EventBusSubscriber(modid = LinhasEFita.MODID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
    public static class ModBus {
        @SubscribeEvent
        public static void models(ModelEvent.RegisterAdditional event) {
            event.register(LupaRenderer.FULL);
            event.register(LupaRenderer.BODY);
        }
    }

    @Mod.EventBusSubscriber(modid = LinhasEFita.MODID, bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
    public static class ForgeBus {
        @SubscribeEvent
        public static void hand(RenderHandEvent event) {
            if (event.getItemStack().getItem() instanceof LupaItem) {
                LupaLens.capture(Minecraft.getInstance());
            }
        }
    }
}
