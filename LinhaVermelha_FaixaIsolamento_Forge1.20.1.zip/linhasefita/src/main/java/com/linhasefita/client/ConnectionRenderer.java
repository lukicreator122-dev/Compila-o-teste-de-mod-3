package com.linhasefita.client;

import com.linhasefita.LinhasEFita;
import com.linhasefita.entity.ConnectionEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.culling.Frustum;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.core.Direction;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.phys.Vec3;

import java.util.Objects;

public class ConnectionRenderer extends EntityRenderer<ConnectionEntity> {
    private static final ResourceLocation TAPE = new ResourceLocation(LinhasEFita.MODID, "textures/entity/faixa.png");
    private static final ResourceLocation PIN = new ResourceLocation(LinhasEFita.MODID, "textures/entity/pino.png");
    private static final float BLOCKS_PER_TEXTURE = 1.0f;
    private static final int[][] PALETTE = {
            {240, 200, 30}, {30, 90, 220}, {20, 170, 170}, {130, 50, 200},
            {200, 30, 30}, {30, 160, 60}, {240, 130, 30}, {240, 100, 160}
    };

    public ConnectionRenderer(EntityRendererProvider.Context ctx) {
        super(ctx);
    }

    @Override
    public ResourceLocation getTextureLocation(ConnectionEntity entity) {
        return PIN;
    }

    @Override
    public boolean shouldRender(ConnectionEntity e, Frustum frustum, double x, double y, double z) {
        return true; // segmentos longos: não fazer culling pela caixa pequena da entidade
    }

    @Override
    public void render(ConnectionEntity e, float yaw, float partialTick, PoseStack ps, MultiBufferSource buf, int light) {
        Vec3 off = e.getOffset();
        PoseStack.Pose pose = ps.last();

        if (e.getKind() == ConnectionEntity.KIND_TAPE) {
            VertexConsumer vc = buf.getBuffer(RenderType.entityCutoutNoCull(TAPE));
            Vec3 n = Vec3.atLowerCornerOf(e.getFaceA().getNormal());
            Vec3 w = off.cross(n);
            if (w.lengthSqr() < 1.0E-6) w = off.cross(new Vec3(0, 1, 0));
            if (w.lengthSqr() < 1.0E-6) w = new Vec3(1, 0, 0);
            w = w.normalize().scale(0.125);
            float uEnd = (float) off.length() / BLOCKS_PER_TEXTURE;
            quad(vc, pose, Vec3.ZERO.subtract(w), off.subtract(w), off.add(w), Vec3.ZERO.add(w),
                    0f, 0f, uEnd, 1f, 255, 255, 255, light, n);
        } else {
            VertexConsumer vc = buf.getBuffer(RenderType.entityCutoutNoCull(PIN));
            if (off.lengthSqr() > 1.0E-6) {
                Vec3 d = off.normalize();
                Vec3 p1 = d.cross(new Vec3(0, 1, 0));
                if (p1.lengthSqr() < 1.0E-6) p1 = new Vec3(1, 0, 0);
                p1 = p1.normalize().scale(0.012);
                Vec3 p2 = d.cross(p1).normalize().scale(0.012);
                quad(vc, pose, Vec3.ZERO.subtract(p1), off.subtract(p1), off.add(p1), Vec3.ZERO.add(p1),
                        0.5f, 0.5f, 0.5f, 0.5f, 200, 15, 15, light, d);
                quad(vc, pose, Vec3.ZERO.subtract(p2), off.subtract(p2), off.add(p2), Vec3.ZERO.add(p2),
                        0.5f, 0.5f, 0.5f, 0.5f, 200, 15, 15, light, d);
            }
            pin(vc, pose, Vec3.ZERO, e.getFaceA(), colorFor(e.position()), light);
            pin(vc, pose, off, e.getFaceB(), colorFor(e.position().add(off)), light);
        }
    }

    private static int[] colorFor(Vec3 p) {
        int h = Objects.hash(Math.round(p.x * 10), Math.round(p.y * 10), Math.round(p.z * 10));
        return PALETTE[Math.floorMod(h, PALETTE.length)];
    }

    private static void pin(VertexConsumer vc, PoseStack.Pose pose, Vec3 c, Direction f, int[] col, int light) {
        Vec3 n = Vec3.atLowerCornerOf(f.getNormal());
        Vec3 u = Math.abs(n.y) > 0.5 ? new Vec3(1, 0, 0) : new Vec3(0, 1, 0);
        Vec3 v = n.cross(u).normalize();
        double hs = 0.07;
        Vec3 ctr = c.add(n.scale(0.005));
        Vec3 us = u.scale(hs), vs = v.scale(hs);
        quad(vc, pose, ctr.subtract(us).subtract(vs), ctr.add(us).subtract(vs), ctr.add(us).add(vs), ctr.subtract(us).add(vs),
                0f, 0f, 1f, 1f, col[0], col[1], col[2], light, n);
    }

    private static void quad(VertexConsumer vc, PoseStack.Pose pose, Vec3 p0, Vec3 p1, Vec3 p2, Vec3 p3,
                             float u0, float v0, float u1, float v1, int r, int g, int b, int light, Vec3 n) {
        vtx(vc, pose, p0, u0, v0, r, g, b, light, n);
        vtx(vc, pose, p1, u1, v0, r, g, b, light, n);
        vtx(vc, pose, p2, u1, v1, r, g, b, light, n);
        vtx(vc, pose, p3, u0, v1, r, g, b, light, n);
    }

    private static void vtx(VertexConsumer vc, PoseStack.Pose pose, Vec3 p, float u, float v,
                            int r, int g, int b, int light, Vec3 n) {
        vc.vertex(pose.pose(), (float) p.x, (float) p.y, (float) p.z)
                .color(r, g, b, 255)
                .uv(u, v)
                .overlayCoords(OverlayTexture.NO_OVERLAY)
                .uv2(light)
                .normal(pose.normal(), (float) n.x, (float) n.y, (float) n.z)
                .endVertex();
    }
}
