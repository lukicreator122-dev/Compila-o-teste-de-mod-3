package com.linhasefita.client;

import com.linhasefita.LinhasEFita;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.geom.EntityModelSet;
import net.minecraft.client.renderer.BlockEntityWithoutLevelRenderer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.Sheets;
import net.minecraft.client.renderer.blockentity.BlockEntityRenderDispatcher;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.client.resources.model.BakedModel;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;

public class LupaRenderer extends BlockEntityWithoutLevelRenderer {
    /** Modelo completo (com vidro) e modelo só do corpo (a lente vem da captura). */
    public static final ResourceLocation FULL = new ResourceLocation(LinhasEFita.MODID, "item/lupa_hand");
    public static final ResourceLocation BODY = new ResourceLocation(LinhasEFita.MODID, "item/lupa_corpo");

    // área da lente no espaço do modelo (4.5..11.5 / 7.5..14.5 em pixels, z = 8)
    private static final float X0 = 0.28125f, X1 = 0.71875f, Y0 = 0.46875f, Y1 = 0.90625f, Z = 0.5f;

    public LupaRenderer(BlockEntityRenderDispatcher dispatcher, EntityModelSet models) {
        super(dispatcher, models);
    }

    @Override
    public void renderByItem(ItemStack stack, ItemDisplayContext ctx, PoseStack ps, MultiBufferSource buf,
                             int light, int overlay) {
        Minecraft mc = Minecraft.getInstance();
        boolean first = ctx.firstPerson();
        boolean lens = first && LupaLens.ready();
        BakedModel model = mc.getModelManager().getModel(lens ? BODY : FULL);
        VertexConsumer vc = buf.getBuffer(Sheets.cutoutBlockSheet());
        mc.getItemRenderer().renderModelLists(model, stack, light, overlay, ps, vc);
        if (lens) drawLens(ps, buf);
    }

    private static void drawLens(PoseStack ps, MultiBufferSource buf) {
        VertexConsumer vc = buf.getBuffer(RenderType.entityCutout(LupaLens.LOCATION));
        PoseStack.Pose pose = ps.last();
        int light = 15728880;
        // frente
        v(vc, pose, X0, Y0, Z, 0f, 0f, light, 1f);
        v(vc, pose, X1, Y0, Z, 1f, 0f, light, 1f);
        v(vc, pose, X1, Y1, Z, 1f, 1f, light, 1f);
        v(vc, pose, X0, Y1, Z, 0f, 1f, light, 1f);
        // verso (espelhado para ler certo do outro lado)
        v(vc, pose, X1, Y0, Z, 0f, 0f, light, -1f);
        v(vc, pose, X0, Y0, Z, 1f, 0f, light, -1f);
        v(vc, pose, X0, Y1, Z, 1f, 1f, light, -1f);
        v(vc, pose, X1, Y1, Z, 0f, 1f, light, -1f);
    }

    private static void v(VertexConsumer vc, PoseStack.Pose pose, float x, float y, float z,
                          float u, float v, int light, float nz) {
        vc.vertex(pose.pose(), x, y, z)
                .color(255, 255, 255, 255)
                .uv(u, v)
                .overlayCoords(OverlayTexture.NO_OVERLAY)
                .uv2(light)
                .normal(pose.normal(), 0f, 0f, nz)
                .endVertex();
    }
}
