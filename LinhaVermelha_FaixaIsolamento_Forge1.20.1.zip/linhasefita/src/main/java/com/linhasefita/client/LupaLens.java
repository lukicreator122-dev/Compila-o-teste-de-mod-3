package com.linhasefita.client;

import com.linhasefita.LinhasEFita;
import com.mojang.blaze3d.pipeline.RenderTarget;
import com.mojang.blaze3d.pipeline.TextureTarget;
import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.texture.AbstractTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.packs.resources.ResourceManager;
import org.lwjgl.opengl.GL30;

/** Captura o centro da tela (com zoom) numa textura de 256x256 usada como lente da lupa. */
public class LupaLens {
    public static final ResourceLocation LOCATION = new ResourceLocation(LinhasEFita.MODID, "dynamic/lupa_lente");
    public static float ZOOM = 3.0f;
    private static final int SIZE = 256;

    private static TextureTarget target;
    private static boolean ready;
    private static boolean broken;

    private LupaLens() {}

    public static boolean ready() {
        return ready && !broken;
    }

    public static void capture(Minecraft mc) {
        if (broken) return;
        try {
            if (target == null) {
                target = new TextureTarget(SIZE, SIZE, false, Minecraft.ON_OSX);
                final TextureTarget t = target;
                mc.getTextureManager().register(LOCATION, new AbstractTexture() {
                    @Override
                    public void load(ResourceManager manager) {
                    }

                    @Override
                    public int getId() {
                        return t.getColorTextureId();
                    }
                });
            }
            RenderTarget main = mc.getMainRenderTarget();
            int w = main.width;
            int h = main.height;
            int s = Math.max(8, Math.round(h / ZOOM));
            int x0 = (w - s) / 2;
            int y0 = (h - s) / 2;

            GlStateManager._glBindFramebuffer(GL30.GL_READ_FRAMEBUFFER, main.frameBufferId);
            GlStateManager._glBindFramebuffer(GL30.GL_DRAW_FRAMEBUFFER, target.frameBufferId);
            GL30.glBlitFramebuffer(x0, y0, x0 + s, y0 + s, 0, 0, SIZE, SIZE,
                    GL30.GL_COLOR_BUFFER_BIT, GL30.GL_LINEAR);

            // deixa o alfa da textura em 1
            GlStateManager._glBindFramebuffer(GL30.GL_FRAMEBUFFER, target.frameBufferId);
            RenderSystem.colorMask(false, false, false, true);
            RenderSystem.clearColor(0f, 0f, 0f, 1f);
            RenderSystem.clear(GL30.GL_COLOR_BUFFER_BIT, Minecraft.ON_OSX);
            RenderSystem.colorMask(true, true, true, true);

            main.bindWrite(true);
            ready = true;
        } catch (Throwable t) {
            broken = true;
            LinhasEFita.LOG.error("Lente da lupa desativada (falha na captura)", t);
            try {
                mc.getMainRenderTarget().bindWrite(true);
            } catch (Throwable ignored) {
            }
        }
    }
}
