package com.linhasefita;

import com.linhasefita.entity.ConnectionEntity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITIES =
            DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, LinhasEFita.MODID);

    public static final RegistryObject<EntityType<ConnectionEntity>> CONEXAO = ENTITIES.register("conexao",
            () -> EntityType.Builder.<ConnectionEntity>of(ConnectionEntity::new, MobCategory.MISC)
                    .sized(0.2f, 0.2f)
                    .clientTrackingRange(10)
                    .updateInterval(20)
                    .fireImmune()
                    .noSummon()
                    .build("conexao"));
}
